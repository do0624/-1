function You(name,hp,attack,dod){
this.name=name;
this.hp=hp;
this.hlhp=hp;
this.attack=attack;
this.dod=dod;

}
function Mom(name,hp,attack,dod){
    this.name=name;
    this.hp=hp;
    this.hlhp=hp;
    this.attack=attack;
    this.dod=dod;

}



window.onload = function(){
    n=document.getElementById('name')
    nn=Math.floor(Math.random()*50)+50
    nnn=Math.floor(Math.random()*5)+5
    nnnn=Math.floor(Math.random()*5)+1
    // mama=document.inputMode('name')
    }
    function adad(){
        ne=n.value
        ne=new You(ne,nn,nnn,nnnn)
        document.write("이름:"+ne.name+'<br>'+"hp:"+ne.hp+'<br>'+"힘:"+ne.attack+'<br>'+"방어:"+ne.dod);
    
    }
    
    mm=Math.floor(Math.random()*50)+1;
    mmm=Math.floor(Math.random()*10)+1;
    mmmm=Math.floor(Math.random()*3)+1;
    
    mom_1=new Mom(mom_1,mm,mmm,mmmm)
    mom_2=new Mom(mom_2,mm,mmm,mmmm)
    mom_3=new Mom(mom_3,mm,mmm,mmmm)
    mom_4=new Mom(mom_4,mm,mmm,mmmm)
    mom_5=new Mom(mom_5,mm,mmm,mmmm)



