

ioop=true
while(ioop){
ioop=vs()
}
function vs(){
var plavda = attack_1(ne.attack);
var momda = attack_1(mom_1.attack);

}
